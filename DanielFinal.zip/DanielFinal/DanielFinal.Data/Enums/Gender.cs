﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DanielFinal.Data.Enums
{
    public enum Gender
    {
        Male = 1,
        Female = 2,
        Other = 3
    }
}
