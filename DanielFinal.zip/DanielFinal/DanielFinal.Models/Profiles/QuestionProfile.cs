﻿using AutoMapper;
using DanielFinal.Data.Entities;
using DanielFinal.Models.Models.Question;
using System;
using System.Collections.Generic;
using System.Text;

namespace DanielFinal.Models.Profiles
{
    public class QuestionProfile
          : Profile
    {
        public QuestionProfile()
        {
            CreateMap<Question, QuestionBaseModel>()
                .ReverseMap();

            CreateMap<Question, QuestionExtendedModel>();

            CreateMap<QuestionCreateModel, Question>();
            CreateMap<QuestionUpdateModel, Question>();
        }
    }
}
