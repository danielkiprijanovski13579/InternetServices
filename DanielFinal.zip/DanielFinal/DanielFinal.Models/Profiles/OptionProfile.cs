﻿using AutoMapper;
using DanielFinal.Data.Entities;
using DanielFinal.Models.Models.Option;
using System;
using System.Collections.Generic;
using System.Text;

namespace DanielFinal.Models.Profiles
{
    public class OptionProfile
        : Profile
    {
        public OptionProfile()
        {
            CreateMap<Option, OptionBaseModel>()
                .ReverseMap();

            CreateMap<Option, OptionExtendedModel>();

            CreateMap<OptionCreateModel, Option>();
            CreateMap<OptionUpdateModel, Option>();
        }
    }
}
