﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace DanielFinal.Models.Models.Question
{
    public class QuestionExtendedModel
    {
        public int Id { get; set; }
        [Required]
        public string Text { get; set; }
        [DisplayName("Enter the description")]
        public string Description { get; set; }

      //  public virtual IEnumerable<Option> Options { get; set; }
    }
}
