﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using DanielFinal.Models.Models.Option;

namespace DanielFinal.Services.Abstraction
{
    public interface IOptionService
    {

        Task<IEnumerable<OptionBaseModel>> Get();
        Task<OptionExtendedModel> Get(int id);
        Task<OptionBaseModel> Insert(OptionCreateModel model);
        Task<OptionBaseModel> Update(OptionUpdateModel model);
        Task<bool> Delete(int id);
    }
}
