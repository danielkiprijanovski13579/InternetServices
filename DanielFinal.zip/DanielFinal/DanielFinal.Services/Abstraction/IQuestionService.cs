﻿using DanielFinal.Models.Models.Question;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace DanielFinal.Services.Abstraction
{
    public interface IQuestionService
    {
        Task<IEnumerable<QuestionBaseModel>> Get();
        Task<QuestionExtendedModel> Get(int id);
        Task<QuestionBaseModel> Insert(QuestionCreateModel model);
        Task<QuestionBaseModel> Update(QuestionUpdateModel model);
        Task<bool> Delete(int id);


    }
}
