﻿using System.Collections.Generic;
using System.Threading.Tasks;
using AutoMapper;
using DanielFinal.Data;
using DanielFinal.Data.Entities;
using DanielFinal.Models.Models.Option;
using DanielFinal.Services.Abstraction;
using Microsoft.EntityFrameworkCore;

namespace DanielFinal.Services.Services
{
    public class OptionService
        : IOptionService
    {
        private readonly DanielFinalDbContext _context;
        private readonly IMapper _mapper;

        public OptionService(DanielFinalDbContext context, IMapper mapper)
        {
            _context = context;
            _mapper = mapper;
        }

        public async Task<IEnumerable<OptionBaseModel>> Get(int id)
        {
            var matches = await _context.Options.ToListAsync();
            return _mapper.Map<IEnumerable<OptionBaseModel>>(matches);
        }

      
        public async Task<IEnumerable<OptionBaseModel>> Get()
        {
            var options = await _context.Options.ToListAsync();
            return _mapper.Map<IEnumerable<OptionBaseModel>>(options);
        }

        public async Task<OptionBaseModel> Insert(OptionCreateModel model)
        {
            var entity = _mapper.Map<Option>(model);

            await _context.Options.AddAsync(entity);
            await SaveAsync();

            return _mapper.Map<OptionBaseModel>(entity);
        }

        public async Task<OptionBaseModel> Update(OptionUpdateModel model)
        {
            var entity = _mapper.Map<Option>(model);

            _context.Options.Attach(entity);
            _context.Entry(entity).State = EntityState.Modified;

            await SaveAsync();

            return _mapper.Map<OptionBaseModel>(entity);
        }

        public async Task<bool> Delete(int id)
        {
            var entity = await _context.Options.FindAsync(id);
            _context.Options.Remove(entity);
            return await SaveAsync() > 0;
        }

        public async Task<int> SaveAsync()
        {
            return await _context.SaveChangesAsync();
        }

        Task<OptionExtendedModel> IOptionService.Get(int id)
        {
            throw new System.NotImplementedException();
        }
    }
}
