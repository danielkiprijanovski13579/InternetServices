﻿using System.Collections.Generic;
using System.Threading.Tasks;
using AutoMapper;
using DanielFinal.Data;
using DanielFinal.Data.Entities;
using DanielFinal.Models.Models.Question;
using DanielFinal.Services.Abstraction;
using Microsoft.EntityFrameworkCore;

namespace DanielFinal.Services.Services
{
    public class QuestionService
        : IQuestionService
    {
        private readonly DanielFinalDbContext _context;
        private readonly IMapper _mapper;

        public QuestionService(DanielFinalDbContext context, IMapper mapper)
        {
            _context = context;
            _mapper = mapper;
        }

        public async Task<IEnumerable<QuestionBaseModel>> Get()
        {
            var matches = await _context.Questions.ToListAsync();
            return _mapper.Map<IEnumerable<QuestionBaseModel>>(matches);
        }

        

        public async Task<QuestionBaseModel> Insert(QuestionCreateModel model)
        {
            var entity = _mapper.Map<Question>(model);

            await _context.Questions.AddAsync(entity);
            await SaveAsync();

            return _mapper.Map<QuestionBaseModel>(entity);
        }

        public async Task<QuestionBaseModel> Update(QuestionUpdateModel model)
        {
            var entity = _mapper.Map<Question>(model);

            _context.Questions.Attach(entity);
            _context.Entry(entity).State = EntityState.Modified;

            await SaveAsync();

            return _mapper.Map<QuestionBaseModel>(entity);
        }

        public async Task<bool> Delete(int id)
        {
            var entity = await _context.Questions.FindAsync(id);
            _context.Questions.Remove(entity);
            return await SaveAsync() > 0;
        }

        public async Task<int> SaveAsync()
        {
            return await _context.SaveChangesAsync();
        }

        public Task<QuestionExtendedModel> Get(int id)
        {
            throw new System.NotImplementedException();
        }
    }
}